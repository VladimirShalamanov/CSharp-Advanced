﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public interface ICitizens
    {
        public string Name { get; }
        public int Age { get; }
        public string Id { get; }
    }
}
