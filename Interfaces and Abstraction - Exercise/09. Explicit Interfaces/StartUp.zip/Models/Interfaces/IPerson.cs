﻿namespace P09.ExplicitInterfaces.Models.Interfaces
{
    public interface IPerson
    {
        string Name { get; }
        int Age { get; }
        void GetName();
    }
}
