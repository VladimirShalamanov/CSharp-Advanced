﻿namespace PlanetWars.Models.MilitaryUnits
{
    public class StormTroopers : MilitaryUnit
    {
        private const double InitCost = 2.5;

        public StormTroopers()
             : base(InitCost)
        {
        }
    }
}
