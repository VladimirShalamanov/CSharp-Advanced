﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenericScale
{
    public class StartUp
    {
        static void Main(string[] args)
        {

        }
    }
}
