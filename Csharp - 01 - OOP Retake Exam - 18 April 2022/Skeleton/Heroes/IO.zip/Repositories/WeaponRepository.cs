﻿namespace Heroes.Repositories
{
    using Contracts;
    using Models.Contracts;
    using System.Collections.Generic;
    using System.Linq;

    public class WeaponRepository : IRepository<IWeapon>
    {
        private readonly IList<IWeapon> models;

        public WeaponRepository() : base()
        {
            this.models = new List<IWeapon>();
        }

        public IReadOnlyCollection<IWeapon> Models => (IReadOnlyCollection<IWeapon>)models;

        public void Add(IWeapon model)
        {
            if (this.models.All(n => n.Name != model.Name))
            {
                this.models.Add(model);
            }
        }

        public IWeapon FindByName(string name)
        {
            var weapon = this.models.FirstOrDefault(n => n.Name == name);
            if (weapon != null)
            {
                return weapon;
            }
            return null;
        }

        public bool Remove(IWeapon model)
        {
            var weaponToRemove = this.models.FirstOrDefault(n => n.Name == model.Name);
            if (weaponToRemove != null)
            {
                this.models.Remove(weaponToRemove);
                return true;
            }
            return false;
        }
    }
}
