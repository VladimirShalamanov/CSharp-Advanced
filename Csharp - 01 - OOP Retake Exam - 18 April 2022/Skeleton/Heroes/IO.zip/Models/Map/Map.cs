﻿namespace Heroes.Models.Map
{
    using Contracts;
    using Heroes;
    using System.Collections.Generic;
    using System.Linq;

    public class Map : IMap
    {
        public string Fight(ICollection<IHero> players)
        {
            var knights = new List<Hero>();
            var berbarians = new List<Berbarian>();

            foreach (var p in players)
            {
                if (p is Knight)
                {
                    knights.Add(p as Knight);
                }
                else
                {
                    berbarians.Add(p as Berbarian);
                }
            }

            while (knights.Any(k => k.IsAlive) ||
                  berbarians.Any(b => b.IsAlive))
            {
                foreach (var knight in knights.Where(k => k.IsAlive))
                {
                    foreach (var berbarian in berbarians.Where(b => b.IsAlive))
                    {
                        int damage = knight.Weapon.DoDamage();
                        berbarian.TakeDamage(damage);
                    }
                }
                foreach (var berbarian in berbarians.Where(b => b.IsAlive))
                {
                    foreach (var knight in knights.Where(k => k.IsAlive))
                    {
                        int damage = berbarian.Weapon.DoDamage();
                        knight.TakeDamage(damage);
                    }
                }
            }

            if (knights.Any(k => k.IsAlive))
            {
                int numK = knights.FindAll(k => k.IsAlive).Count;
                return $"The knights took {numK} casualties but won the battle.";
            }

            int numB = berbarians.FindAll(b => b.IsAlive).Count;
            return $"The barbarians took {numB} casualties but won the battle.";
        }
    }
}
