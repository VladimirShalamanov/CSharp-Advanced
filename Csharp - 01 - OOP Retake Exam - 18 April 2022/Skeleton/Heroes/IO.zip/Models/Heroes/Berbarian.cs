﻿namespace Heroes.Models.Heroes
{
    using Contracts;

    public class Berbarian : Hero, IHero
    {
        public Berbarian(string name, int health, int armour)
            : base(name, health, armour)
        {
        }
    }
}
