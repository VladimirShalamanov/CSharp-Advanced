﻿namespace Heroes.Models.Heroes
{
    using Contracts;
    using System;

    public class Hero : IHero
    {
        private string name;
        private int health;
        private int armour;
        private bool isAlive;
        private IWeapon weapon;

        //ctor
        public Hero(string name, int health, int armour)
        {
            this.Name = name;
            this.Health = health;
            this.Armour = armour;
        }

        public string Name
        {
            get => this.name;
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("Hero name cannot be null or empty.");
                }

                this.name = value;
            }
        }

        public int Health
        {
            get => this.health;
            private set
            {
                if (value < 0)
                {
                    throw new ArgumentException("Hero health cannot be below 0.");
                }

                this.health = value;
            }
        }

        public int Armour
        {
            get => this.armour;
            private set
            {
                if (value < 0)
                {
                    throw new ArgumentException("Hero armour cannot be below 0.");
                }

                this.health = value;
            }
        }

        public IWeapon Weapon
        {
            get => this.Weapon;
            private set
            {
                if (this.Weapon == null)
                {
                    throw new ArgumentException("Weapon cannot be null.");
                }
            }
        }

        public bool IsAlive
        {
            get => isAlive;
            private set
            {
                if (Health > 0)
                {
                    isAlive = true;
                }
                else
                {
                    isAlive = false;
                }
            }
        }

        public void AddWeapon(IWeapon weapon)
        {
            if (this.weapon == null)
            {
                this.weapon = weapon;
            }
        }

        public void TakeDamage(int points)
        {
            if (this.Armour > 0)
            {
                this.Armour -= points;
                if (this.Armour <= 0)
                {
                    points = Math.Abs(this.Armour);
                    this.Armour = 0;
                }
            }
            if (this.Health > 0 && this.Armour == 0)
            {
                this.Health -= points;
                if (this.Health <= 0)
                {
                    this.Health = 0;
                    isAlive = false;
                }
            }
        }
    }
}
