﻿namespace Heroes.Models.Weapons
{
    using Contracts;

    public class Claymore : Weapon, IWeapon
    {
        private int damage;
        public Claymore(string name, int durability)
            : base(name, durability)
        {
            damage = 20;
        }

        public override int DoDamage()
        {
            Durability--;
            if (this.Durability == 0)
            {
                return 0;
            }

            return damage;
        }
    }
}
