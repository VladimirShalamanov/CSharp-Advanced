﻿namespace Easter.Models.Workshops
{
    using Contracts;
    using Models.Bunnies.Contracts;
    using Models.Eggs.Contracts;
    using System.Linq;

    public class Workshop : IWorkshop
    {
        public Workshop()
        {
        }

        public void Color(IEgg egg, IBunny bunny)
        {
            if (bunny.Dyes.Any())
            {
                foreach (var dye in bunny.Dyes)
                {
                    while (!egg.IsDone() || bunny.Energy > 0 || !dye.IsFinished())
                    {
                        bunny.Work();
                        dye.Use();
                        egg.GetColored();
                    }
                    if (egg.IsDone()) return;
                }
            }
        }
    }
}
