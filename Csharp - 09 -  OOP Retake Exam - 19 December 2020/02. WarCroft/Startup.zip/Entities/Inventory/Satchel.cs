﻿namespace WarCroft.Entities.Inventory
{
    public class Satchel : Bag
    {
        private const int InitCap = 20;

        public Satchel()
             : base(InitCap)
        {
        }
    }
}
