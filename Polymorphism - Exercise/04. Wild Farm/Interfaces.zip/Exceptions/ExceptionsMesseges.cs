﻿namespace P04.WildFarm.Exceptions
{
    using System;

    public class ExceptionsMesseges : Exception
    {
        public const string InvalidFoodException = "{0} does not eat {1}!";
    }
}
