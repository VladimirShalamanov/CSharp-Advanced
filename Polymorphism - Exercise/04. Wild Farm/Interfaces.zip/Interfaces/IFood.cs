﻿namespace P04.WildFarm.Interfaces
{
 
    public interface IFood
    {
        int Quantity { get; }
    }
}
