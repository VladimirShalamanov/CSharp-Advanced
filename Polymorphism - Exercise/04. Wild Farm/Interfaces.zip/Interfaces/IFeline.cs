﻿namespace P04.WildFarm.Interfaces
{
    public interface IFeline
    {
        string Breed { get; }
    }
}
