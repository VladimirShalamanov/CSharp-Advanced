﻿namespace P04.WildFarm.Interfaces
{
    public interface IBird
    {
        double WingSize { get; }
    }
}
