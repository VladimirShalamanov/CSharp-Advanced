﻿namespace P04.WildFarm.Interfaces
{
    public interface IMammal
    {
        string LivingRegion { get; }
    }
}
