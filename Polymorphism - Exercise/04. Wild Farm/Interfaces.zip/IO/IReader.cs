﻿namespace P04.WildFarm.IO
{
   
    public interface IReader
    {
        public string ReadLine();
    }
}
