﻿namespace P02.VehiclesExtension.Core
{
    public interface IEngine
    {
        void Start();
    }
}
