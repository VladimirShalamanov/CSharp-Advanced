﻿namespace CarManager.Tests
{
    using NUnit.Framework;

    [TestFixture]
    public class CarManagerTestsBase
    {
        private double FuelAmount;
    }
}