﻿namespace SpaceStation.Models.Mission
{
    using System.Linq;
    using Contracts;
    using System.Collections.Generic;
    using SpaceStation.Models.Astronauts.Contracts;
    using SpaceStation.Models.Planets.Contracts;

    public class Mission : IMission
    {
        public void Explore(IPlanet planet, ICollection<IAstronaut> astronauts)
        {
            foreach (IAstronaut ast in astronauts.Where(a => a.CanBreath))
            {
                if (planet.Items.Any())
                {
                    foreach (var item in planet.Items)
                    {
                        ast.Breath();
                        ast.Bag.Items.Add(item);
                        ast.Bag.Items.Add(item);
                        planet.Items.Remove(item);
                        if (!ast.CanBreath) break;
                    }
                }
            }
        }
    }
}
