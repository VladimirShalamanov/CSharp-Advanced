﻿namespace NavalVessels.Repositories
{
    internal interface IVesselRepository
    {
    }
}
