﻿//namespace NavalVessels.Core
//{
//    using System;
//    using System.Collections.Generic;
//    using System.Linq;
//    using System.Text;

//    using Contracts;
//    using NavalVessels.Models;
//    using NavalVessels.Models.Contracts;
//    using NavalVessels.Repositories;
//    using Utilities.Messages;

//    public class Controller : IController
//    {
//        private VesselRepository vesselRep;
//        private ICollection<ICaptain> capitans;

//        public Controller()
//        {
//            this.vesselRep = new VesselRepository();
//            this.capitans = new List<ICaptain>();
//        }

//        public string HireCaptain(string fullName)
//        {
//            var captain = new Captain(fullName);
//            if (this.capitans.Any(x => x == captain))
//            {
//                return String.Format(OutputMessages.CaptainIsAlreadyHired, fullName);
//            }
//            this.capitans.Add(captain);
//            return String.Format(OutputMessages.SuccessfullyAddedCaptain, fullName);
//        }

//        public string AssignCaptain(string selectedCaptainName, string selectedVesselName)
//        {
//            throw new NotImplementedException();
//        }

//        public string AttackVessels(string attackingVesselName, string defendingVesselName)
//        {
//            throw new NotImplementedException();
//        }

//        public string CaptainReport(string captainFullName)
//        {
//            throw new NotImplementedException();
//        }


//        public string ProduceVessel(string name, string vesselType, double mainWeaponCaliber, double speed)
//        {
//            throw new NotImplementedException();
//        }

//        public string ServiceVessel(string vesselName)
//        {
//            throw new NotImplementedException();
//        }

//        public string ToggleSpecialMode(string vesselName)
//        {
//            throw new NotImplementedException();
//        }

//        public string VesselReport(string vesselName)
//        {
//            throw new NotImplementedException();
//        }
//    }
//}
