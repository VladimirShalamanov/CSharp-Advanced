﻿namespace Formula1.Models
{
    public class Williams : FormulaOneCar
    {
        public Williams(string model, int horseP, double engineDip)
            : base(model, horseP, engineDip)
        {
        }
    }
}
