﻿namespace Formula1.Models
{
    public class Ferrari : FormulaOneCar
    {
        public Ferrari(string model, int horseP, double engineDip)
            : base(model, horseP, engineDip)
        {
        }
    }
}
