﻿namespace Formula1.Models
{
    using System;
    
    using Contracts;
    using Utilities;
    public abstract class FormulaOneCar : IFormulaOneCar
    {
        private string model;
        private int horseP;
        private double engineDip;

        public FormulaOneCar(string model, int horseP, double engineDip)
        {
            this.model = model;
            this.horseP = horseP;
            this.engineDip = engineDip;
        }

        public string Model
        {
            get => this.model;
            private set
            {
                if (string.IsNullOrWhiteSpace(value) || value.Length < 3)
                {
                    throw new ArgumentException(String.Format(ExceptionMessages.InvalidF1CarModel, value));
                }

                this.model = value;
            }
        }

        public int Horsepower
        {
            get => this.horseP;
            private set
            {
                if (value < 900 && value > 1050)
                {
                    throw new ArgumentException(String.Format(ExceptionMessages.InvalidF1HorsePower, value));
                }

                this.horseP = value;
            }
        }

        public double EngineDisplacement
        {
            get => this.engineDip;
            private set
            {
                if (value < 1.6 || value > 2.00)
                {
                    throw new ArgumentException(String.Format(ExceptionMessages.InvalidF1EngineDisplacement, value));
                }
            }
        }

        public double RaceScoreCalculator(int laps) => this.EngineDisplacement / this.Horsepower * laps;
    }
}
